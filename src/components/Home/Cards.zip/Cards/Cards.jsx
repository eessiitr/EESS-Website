import React, {Component} from "react";
import "./card-style.css";
import Card from "./CardUI";

<style>
@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap');
</style>

class Cards extends Component {
 render(){
     return(
         <div className="container-fluid d-flex justify-content-center">
             <div className="row">
                 
                 <div className="CardContainer" >
                 <h3 color="rgba(255, 255, 255, 1)">Updates</h3>
                 <div className="heading_decor1"></div>
                 <div className="col-md-12">
                     <Card/>
                 </div>
                 <div className="col-md-12">
                      <Card/>
                 </div>
                 <div className="col-md-12">
                       <Card/>
                 </div>
                 <div className="col-md-12">
                       <Card/>
                 </div>
                 <div className="col-md-12" >
                       <Card/>
                 </div>
                 </div>
             </div>
         </div>
     );
 }
}

export default Cards;