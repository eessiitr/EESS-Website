import React from "react";
import "./card-style.css";
import img from "./Freshers video 1.jpg"


const Card = props=>{
    return(
        <div className="card text-center">

             <img src={img} class="card-img-left" alt="..." />
            <div className="card-body text-dark">
                <h4 className="card-title">Freshers’ Video out now!!</h4>
              
                <p className="card-text text-secondary">
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto asperiores tenetur pariatur quas fugit fugiat vel qui eveniet accusamus similique obcaecati consequuntur deleniti, animi praesentium fuga ad eaque omnis. Perferendis modi quae nisi quos?
                </p>
                <a href="#" className="btn btn-outline-success">
                    Go anywhere
                </a>

            </div>
        </div>
    );
};

export default Card